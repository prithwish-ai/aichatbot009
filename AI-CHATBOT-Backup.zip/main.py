import sys
import os
import argparse

# Add path for imports
sys.path.append(os.path.join(os.path.dirname(__file__), 'core'))
sys.path.append(os.path.join(os.path.dirname(__file__), 'utils'))
sys.path.append(os.path.join(os.path.dirname(__file__), 'tests'))

def main():
    """Main entry point for the application."""
    parser = argparse.ArgumentParser(description="ITI AI Chatbot")
    parser.add_argument("--cli", action="store_true", help="Run in CLI mode instead of GUI")
    parser.add_argument("--continuous-learning", action="store_true", help="Enable continuous learning")
    parser.add_argument("--voice", action="store_true", help="Enable voice interaction")
    parser.add_argument("--demo", action="store_true", help="Run the simple demo version")
    args = parser.parse_args()
    
    if args.demo:
        # Run the simplified demo
        try:
            from demo.simple_gemini_app import main as demo_main
            return demo_main()
        except ImportError as e:
            print(f"Error importing demo app: {e}")
            return 1
            
    elif args.cli:
        # Import here to avoid importing PyQt6 when not needed
        from iti_app import ChatBot
        
        # Run in CLI mode
        chatbot = ChatBot(continuous_learning=args.continuous_learning)
        print("ITI AI Chatbot (CLI Mode)")
        print("Type '!help' for available commands")
        print("Type '!exit' to quit")
        
        while True:
            try:
                user_input = input("\nYou: ").strip()
                
                if user_input.lower() == "!exit":
                    break
                elif user_input.lower() == "!help":
                    print("\nAvailable Commands:")
                    print("!help - Show this help message")
                    print("!clear - Clear conversation history")
                    print("!stats - Show learning statistics")
                    print("!exit - Exit the program")
                    print("!voice - Toggle voice interaction")
                    print("!language <code> - Set language preference")
                    print("!difficulty <level> - Set difficulty level")
                    print("!quiz <topic> <subtopic> - Start a quiz")
                    print("!study <topic> <subtopic> - Get study materials")
                    print("!progress - Show learning progress")
                    print("!recommend - Get personalized recommendations")
                    print("!topics - List available topics")
                    continue
                
                response = chatbot.generate_response(user_input)
                print(f"\nBot: {response}")
                
            except KeyboardInterrupt:
                print("\nExiting...")
                break
            except Exception as e:
                print(f"\nError: {e}")
                continue
    else:
        # Only import GUI components when needed
        try:
            from gui import main as gui_main
            gui_main()
        except ImportError as e:
            print(f"Error importing GUI components: {e}")
            print("Falling back to CLI mode...")
            # Recursively call main with CLI argument
            sys.argv.append("--cli")
            main()
            
    return 0

if __name__ == "__main__":
    sys.exit(main()) 