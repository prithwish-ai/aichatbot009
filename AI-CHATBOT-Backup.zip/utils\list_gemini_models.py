import google.generativeai as genai
import os
from dotenv import load_dotenv

def list_gemini_models():
    """
    List all available Gemini models and their supported generation methods.
    Requires GOOGLE_API_KEY in the .env file.
    """
    # Load API key from .env file
    load_dotenv()
    GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")

    if not GOOGLE_API_KEY:
        print("Error: GOOGLE_API_KEY not found in .env file")
        return False

    # Configure the API
    genai.configure(api_key=GOOGLE_API_KEY)

    try:
        # List available models
        models = genai.list_models()

        # Print the available models and their methods
        print("\nAvailable Gemini Models:")
        print("-" * 50)
        for model in models:
            print(f"Model Name: {model.name}")
            print(f"Supported Methods: {model.supported_generation_methods}")
            print("-" * 50)
        
        return True

    except Exception as e:
        print(f"Error occurred: {str(e)}")
        return False

if __name__ == "__main__":
    list_gemini_models() 