import os
import sys
import google.generativeai as genai
from dotenv import load_dotenv
import colorama
from colorama import Fore, Style

# Initialize colorama for cross-platform colored terminal output
colorama.init()

def setup_api():
    """Configure the Gemini API with API key from environment."""
    print(f"{Fore.GREEN}Setting up Gemini API...{Style.RESET_ALL}")
    
    # Load environment variables
    load_dotenv()
    api_key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
    
    if not api_key:
        print(f"{Fore.RED}Error: No API key found. Please set the GEMINI_API_KEY in your .env file{Style.RESET_ALL}")
        return None
    
    # Configure the Gemini API
    try:
        genai.configure(api_key=api_key)
        print(f"{Fore.GREEN}API key configured successfully{Style.RESET_ALL}")
        return True
    except Exception as e:
        print(f"{Fore.RED}Error configuring Gemini API: {e}{Style.RESET_ALL}")
        return None

def list_available_models(verbose=True):
    """List all available Gemini models.
    
    Args:
        verbose: Whether to print detailed information about each model
        
    Returns:
        List of model objects
    """
    try:
        models = genai.list_models()
        
        if verbose:
            print(f"{Fore.GREEN}Available models:{Style.RESET_ALL}")
            
            for model in models:
                print(f"\n{Fore.CYAN}Model name: {model.name}{Style.RESET_ALL}")
                print(f"Display name: {model.display_name}")
                print(f"Description: {model.description}")
                print(f"Supported generation methods:")
                
                for method in model.supported_generation_methods:
                    print(f"  - {method}")
        
        return models
            
    except Exception as e:
        print(f"{Fore.RED}Error listing models: {e}{Style.RESET_ALL}")
        return []

def main():
    """List available Gemini models."""
    print(f"{Fore.GREEN}=== Available Gemini Models ==={Style.RESET_ALL}")
    
    # Setup API
    if not setup_api():
        return 1
    
    # List models
    models = list_available_models(verbose=True)
    
    if not models:
        print(f"{Fore.RED}No models found or error occurred.{Style.RESET_ALL}")
        return 1
        
    return 0

if __name__ == "__main__":
    sys.exit(main()) 