import pyttsx3
import speech_recognition as sr
from typing import Optional, Dict, Any
import json
import os
from gtts import gTTS
import pygame
import threading
import queue
import time

class VoiceManager:
    """Enhanced voice interaction manager with improved features."""
    
    def __init__(self):
        """Initialize the voice manager with enhanced features."""
        self.engine = pyttsx3.init()
        self.recognizer = sr.Recognizer()
        self.is_speaking = False
        self.is_listening = False
        self.voice_queue = queue.Queue()
        self.stop_speaking = False
        self.stop_listening = False
        
        # Load voice settings
        self.voice_settings = self._load_voice_settings()
        
        # Initialize pygame mixer
        pygame.mixer.init()
        
        # Set up voice properties
        self._setup_voice_properties()
        
    def _load_voice_settings(self) -> Dict[str, Any]:
        """Load voice settings from file."""
        try:
            if os.path.exists("voice_settings.json"):
                with open("voice_settings.json", "r") as f:
                    return json.load(f)
        except Exception as e:
            print(f"Could not load voice settings: {e}")
        
        # Default settings
        return {
            "rate": 150,  # Speech rate
            "volume": 1.0,  # Volume (0.0 to 1.0)
            "pitch": 50,  # Pitch (0 to 100)
            "voice_id": None,  # Voice ID (will be set in _setup_voice_properties)
            "language": "en",  # Language code
            "use_gtts": False,  # Whether to use gTTS for better quality
            "interruptible": True,  # Whether speech can be interrupted
            "auto_detect_language": True,  # Whether to auto-detect language
            "save_audio": False,  # Whether to save audio files
            "audio_dir": "audio_files"  # Directory for saved audio files
        }
    
    def _save_voice_settings(self):
        """Save voice settings to file."""
        try:
            with open("voice_settings.json", "w") as f:
                json.dump(self.voice_settings, f, indent=2)
        except Exception as e:
            print(f"Could not save voice settings: {e}")
    
    def _setup_voice_properties(self):
        """Set up voice properties based on settings."""
        # Set rate
        self.engine.setProperty('rate', self.voice_settings["rate"])
        
        # Set volume
        self.engine.setProperty('volume', self.voice_settings["volume"])
        
        # Set voice
        voices = self.engine.getProperty('voices')
        if voices:
            if self.voice_settings["voice_id"] is None:
                # Try to find a female voice
                for voice in voices:
                    if "female" in voice.name.lower():
                        self.voice_settings["voice_id"] = voice.id
                        break
                if self.voice_settings["voice_id"] is None:
                    self.voice_settings["voice_id"] = voices[0].id
            
            self.engine.setProperty('voice', self.voice_settings["voice_id"])
    
    def set_rate(self, rate: int):
        """Set speech rate.
        
        Args:
            rate: Speech rate (words per minute)
        """
        self.voice_settings["rate"] = rate
        self.engine.setProperty('rate', rate)
        self._save_voice_settings()
    
    def set_volume(self, volume: float):
        """Set speech volume.
        
        Args:
            volume: Volume level (0.0 to 1.0)
        """
        self.voice_settings["volume"] = max(0.0, min(1.0, volume))
        self.engine.setProperty('volume', self.voice_settings["volume"])
        self._save_voice_settings()
    
    def set_pitch(self, pitch: int):
        """Set speech pitch.
        
        Args:
            pitch: Pitch level (0 to 100)
        """
        self.voice_settings["pitch"] = max(0, min(100, pitch))
        self.engine.setProperty('pitch', self.voice_settings["pitch"])
        self._save_voice_settings()
    
    def set_language(self, language: str):
        """Set speech language.
        
        Args:
            language: Language code (e.g., 'en', 'es', 'fr')
        """
        self.voice_settings["language"] = language
        self._save_voice_settings()
    
    def set_voice(self, voice_id: str):
        """Set voice ID.
        
        Args:
            voice_id: ID of the voice to use
        """
        voices = self.engine.getProperty('voices')
        for voice in voices:
            if voice.id == voice_id:
                self.voice_settings["voice_id"] = voice_id
                self.engine.setProperty('voice', voice_id)
                self._save_voice_settings()
                break
    
    def speak(self, text: str, interrupt: bool = True) -> None:
        """Speak text with enhanced features.
        
        Args:
            text: Text to speak
            interrupt: Whether to interrupt current speech
        """
        if interrupt and self.is_speaking:
            self.stop_speaking = True
            self.engine.stop()
            time.sleep(0.1)  # Small delay to ensure clean stop
        
        self.is_speaking = True
        self.stop_speaking = False
        
        if self.voice_settings["use_gtts"]:
            self._speak_with_gtts(text)
        else:
            self._speak_with_pyttsx3(text)
        
        self.is_speaking = False
    
    def _speak_with_pyttsx3(self, text: str):
        """Speak text using pyttsx3."""
        try:
            self.engine.say(text)
            self.engine.runAndWait()
        except Exception as e:
            print(f"Error speaking with pyttsx3: {e}")
    
    def _speak_with_gtts(self, text: str):
        """Speak text using gTTS for better quality."""
        try:
            # Create audio file
            tts = gTTS(text=text, lang=self.voice_settings["language"])
            
            # Save or use temporary file
            if self.voice_settings["save_audio"]:
                os.makedirs(self.voice_settings["audio_dir"], exist_ok=True)
                filename = os.path.join(
                    self.voice_settings["audio_dir"],
                    f"speech_{int(time.time())}.mp3"
                )
                tts.save(filename)
            else:
                filename = "temp_speech.mp3"
                tts.save(filename)
            
            # Play audio
            pygame.mixer.music.load(filename)
            pygame.mixer.music.play()
            
            # Wait for playback to finish
            while pygame.mixer.music.get_busy():
                if self.stop_speaking:
                    pygame.mixer.music.stop()
                    break
                time.sleep(0.1)
            
            # Clean up
            if not self.voice_settings["save_audio"]:
                try:
                    os.remove(filename)
                except:
                    pass
                    
        except Exception as e:
            print(f"Error speaking with gTTS: {e}")
            # Fallback to pyttsx3
            self._speak_with_pyttsx3(text)
    
    def listen(self, timeout: Optional[float] = None, language: Optional[str] = None) -> Optional[str]:
        """Listen for voice input with enhanced features.
        
        Args:
            timeout: Maximum time to wait for input
            language: Language code for recognition
            
        Returns:
            Recognized text or None if recognition failed
        """
        if self.is_listening:
            return None
            
        self.is_listening = True
        self.stop_listening = False
        
        try:
            with sr.Microphone() as source:
                print("Listening...")
                self.recognizer.adjust_for_ambient_noise(source)
                
                try:
                    audio = self.recognizer.listen(
                        source,
                        timeout=timeout,
                        phrase_time_limit=10
                    )
                    
                    if self.stop_listening:
                        return None
                    
                    # Use specified language or auto-detect
                    if language:
                        result = self.recognizer.recognize_google(
                            audio,
                            language=language
                        )
                    elif self.voice_settings["auto_detect_language"]:
                        result = self.recognizer.recognize_google(audio)
                    else:
                        result = self.recognizer.recognize_google(
                            audio,
                            language=self.voice_settings["language"]
                        )
                    
                    return result
                    
                except sr.WaitTimeoutError:
                    print("No speech detected within timeout")
                    return None
                except sr.UnknownValueError:
                    print("Could not understand audio")
                    return None
                except sr.RequestError as e:
                    print(f"Could not request results: {e}")
                    return None
                    
        except Exception as e:
            print(f"Error in voice recognition: {e}")
            return None
        finally:
            self.is_listening = False
    
    def stop(self):
        """Stop current speech or listening."""
        self.stop_speaking = True
        self.stop_listening = True
        self.engine.stop()
        pygame.mixer.music.stop()
    
    def get_available_voices(self) -> list:
        """Get list of available voices.
        
        Returns:
            List of voice information dictionaries
        """
        voices = self.engine.getProperty('voices')
        return [
            {
                "id": voice.id,
                "name": voice.name,
                "languages": voice.languages,
                "gender": "female" if "female" in voice.name.lower() else "male"
            }
            for voice in voices
        ]
    
    def get_voice_settings(self) -> Dict[str, Any]:
        """Get current voice settings.
        
        Returns:
            Dictionary of current voice settings
        """
        return self.voice_settings.copy() 