import os
import sys
import google.generativeai as genai
from dotenv import load_dotenv
import colorama
from colorama import Fore, Style

# Initialize colorama for cross-platform colored terminal output
colorama.init()

def setup_api():
    """Configure the Gemini API with API key from environment."""
    print(f"{Fore.GREEN}Setting up Gemini API...{Style.RESET_ALL}")
    
    # Load environment variables
    load_dotenv()
    api_key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
    
    if not api_key:
        print(f"{Fore.RED}Error: No API key found. Please set the GEMINI_API_KEY in your .env file{Style.RESET_ALL}")
        return None
    
    # Configure the Gemini API
    try:
        genai.configure(api_key=api_key)
        print(f"{Fore.GREEN}API key configured successfully{Style.RESET_ALL}")
        return True
    except Exception as e:
        print(f"{Fore.RED}Error configuring Gemini API: {e}{Style.RESET_ALL}")
        return None

def setup_model():
    """Initialize and return the Gemini model."""
    # Set up the model - use Gemini 2.0 Flash model
    try:
        model_name = "models/gemini-2.0-flash"
        print(f"{Fore.YELLOW}Connecting to model: {model_name}{Style.RESET_ALL}")
        model = genai.GenerativeModel(model_name)
        print(f"{Fore.GREEN}Successfully connected to Gemini 2.0 Flash model{Style.RESET_ALL}")
        return model
    except Exception as e:
        print(f"{Fore.RED}Failed to connect to Gemini 2.0 Flash model: {e}{Style.RESET_ALL}")
        return None

def main():
    """Simple demo application for Gemini API."""
    print(f"{Fore.GREEN}=== Simple Gemini API Demo ==={Style.RESET_ALL}")
    
    # Setup API
    if not setup_api():
        return 1
    
    # Setup model
    model = setup_model()
    if not model:
        return 1
    
    # Create generation config
    generation_config = {
        "temperature": 0.7,
        "top_p": 0.95,
        "top_k": 40,
        "max_output_tokens": 4096,
    }
    
    # Safety settings
    safety_settings = [
        {"category": "HARM_CATEGORY_HARASSMENT", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
        {"category": "HARM_CATEGORY_HATE_SPEECH", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
        {"category": "HARM_CATEGORY_SEXUALLY_EXPLICIT", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
        {"category": "HARM_CATEGORY_DANGEROUS_CONTENT", "threshold": "BLOCK_MEDIUM_AND_ABOVE"},
    ]
    
    # Set up conversation
    conversation_history = []
    system_prompt = """You are an educational AI assistant, designed to help students learn. 
    You provide clear, concise, and accurate information, tailoring your responses to the user's knowledge level.
    When appropriate, include examples and analogies to illustrate concepts."""
    
    print(f"\n{Fore.CYAN}Welcome to the Simple Gemini API Demo!{Style.RESET_ALL}")
    print(f"Type 'exit' to quit the application.")
    
    # Main chat loop
    while True:
        user_input = input(f"\n{Fore.BLUE}You: {Style.RESET_ALL}").strip()
        
        if user_input.lower() == 'exit':
            print(f"{Fore.YELLOW}Goodbye!{Style.RESET_ALL}")
            break
        
        # Build the prompt with history
        prompt = system_prompt + "\n\n"
        
        for exchange in conversation_history[-3:]:  # Include up to 3 most recent exchanges
            prompt += f"User: {exchange['user']}\nAssistant: {exchange['assistant']}\n\n"
        
        prompt += f"User: {user_input}\nAssistant:"
        
        try:
            # Generate response
            response = model.generate_content(
                prompt, 
                generation_config=generation_config,
                safety_settings=safety_settings
            )
            
            # Extract and display the response
            assistant_response = response.text
            print(f"\n{Fore.GREEN}Assistant: {Style.RESET_ALL}{assistant_response}")
            
            # Update conversation history
            conversation_history.append({
                "user": user_input,
                "assistant": assistant_response
            })
            
        except Exception as e:
            print(f"{Fore.RED}Error generating response: {e}{Style.RESET_ALL}")
    
    return 0

if __name__ == "__main__":
    sys.exit(main()) 