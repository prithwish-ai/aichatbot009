import google.generativeai as genai
import os
from dotenv import load_dotenv

def call_gemini_api(prompt, model_name="gemini-pro"):
    """
    Call the Gemini API with a prompt and return the response.
    
    Args:
        prompt (str): The prompt to send to the Gemini API
        model_name (str): The model name to use (default: gemini-pro)
        
    Returns:
        str: The response from the Gemini API or an error message
    """
    # Load API key from .env file
    load_dotenv()
    GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
    
    if not GOOGLE_API_KEY:
        return "Error: GOOGLE_API_KEY not found in .env file"
    
    # Configure the API
    genai.configure(api_key=GOOGLE_API_KEY)
    
    try:
        # Get the model
        model = genai.GenerativeModel(model_name)
        
        # Generate content
        response = model.generate_content(prompt)
        
        # Return the response text
        return response.text
    
    except Exception as e:
        return f"Error calling Gemini API: {str(e)}"

if __name__ == "__main__":
    # Example usage
    prompt = input("Enter your prompt: ")
    model = input("Enter model name (default: gemini-pro): ") or "gemini-pro"
    
    response = call_gemini_api(prompt, model)
    print("\nResponse:")
    print("-" * 50)
    print(response)
    print("-" * 50) 