#!/usr/bin/env python3
"""
Launcher script for AI Chatbot Application
"""

import sys
import os
import argparse
import subprocess
import platform

def get_python_command():
    """Return the appropriate Python command based on OS"""
    if platform.system() == "Windows":
        return "python"
    else:
        return "python3"

def run_command(command):
    """Execute a command and print output in real-time"""
    process = subprocess.Popen(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        universal_newlines=True,
        shell=True
    )
    
    for line in process.stdout:
        print(line, end='')
    
    process.wait()
    return process.returncode

def main():
    """Main function to parse arguments and run the appropriate command"""
    parser = argparse.ArgumentParser(description='AI Chatbot Application Launcher')
    
    # Create a mutually exclusive group for commands
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--demo', action='store_true', help='Run the demo application')
    group.add_argument('--full', action='store_true', help='Run the full application')
    group.add_argument('--gui', action='store_true', help='Run the GUI application')
    group.add_argument('--cli', action='store_true', help='Run the CLI application')
    group.add_argument('--test', action='store_true', help='Run tests')
    group.add_argument('--models', action='store_true', help='List available Gemini models')
    group.add_argument('--gemini', action='store_true', help='Call the Gemini API directly')
    
    # Parse arguments
    args = parser.parse_args()
    
    python_cmd = get_python_command()
    
    # Execute the appropriate command based on arguments
    if args.demo:
        print("Running demo application...")
        return run_command(f"{python_cmd} main.py --demo")
    
    elif args.full:
        print("Running full application...")
        return run_command(f"{python_cmd} main.py")
    
    elif args.gui:
        print("Running GUI application...")
        return run_command(f"{python_cmd} main.py --gui")
    
    elif args.cli:
        print("Running CLI application...")
        return run_command(f"{python_cmd} main.py --cli")
    
    elif args.test:
        print("Running tests...")
        return run_command(f"{python_cmd} tests/test_context.py && {python_cmd} tests/test_voice.py")
    
    elif args.models:
        print("Listing available Gemini models...")
        return run_command(f"{python_cmd} utils/list_gemini_models.py")
        
    elif args.gemini:
        print("Calling Gemini API directly...")
        return run_command(f"{python_cmd} utils/call_gemini_api.py")

if __name__ == "__main__":
    sys.exit(main()) 