#!/usr/bin/env python3
"""
Dataset Creation Utility

This script helps create custom training datasets for the AI chatbot.
"""

import argparse
import json
import os
import sys
import csv
from datetime import datetime


def convert_csv_to_json(csv_file, output_file):
    """Convert a CSV file with question-answer pairs to the required JSON format.
    
    Expected CSV format:
    question,answer[,context]
    """
    data = []
    try:
        with open(csv_file, 'r', encoding='utf-8') as f:
            reader = csv.reader(f)
            # Check for header
            header = next(reader, None)
            if header and header[0].lower() == 'question' and header[1].lower() == 'answer':
                # Has header, continue
                pass
            else:
                # No header or not in expected format, rewind file
                f.seek(0)
            
            for row in reader:
                if len(row) < 2:
                    print(f"Warning: Skipping row with insufficient data: {row}")
                    continue
                    
                item = {
                    "question": row[0],
                    "answer": row[1],
                    "context": row[2] if len(row) > 2 else "",
                    "timestamp": datetime.now().isoformat()
                }
                data.append(item)
        
        # Write to JSON
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
            
        print(f"Successfully converted {len(data)} examples to {output_file}")
        return True
        
    except Exception as e:
        print(f"Error converting CSV to JSON: {e}")
        return False


def merge_datasets(files, output_file):
    """Merge multiple JSON dataset files into one."""
    merged_data = []
    
    for file in files:
        try:
            with open(file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                if isinstance(data, list):
                    merged_data.extend(data)
                else:
                    print(f"Warning: {file} does not contain a list of examples")
        except Exception as e:
            print(f"Error reading {file}: {e}")
    
    # Write merged data
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(merged_data, f, ensure_ascii=False, indent=2)
    
    print(f"Successfully merged {len(merged_data)} examples to {output_file}")
    return True


def add_examples_interactively(output_file):
    """Add examples interactively through command line input."""
    examples = []
    existing_data = []
    
    # Load existing data if file exists
    if os.path.exists(output_file):
        try:
            with open(output_file, 'r', encoding='utf-8') as f:
                existing_data = json.load(f)
                if isinstance(existing_data, list):
                    examples = existing_data
                    print(f"Loaded {len(examples)} existing examples from {output_file}")
        except Exception as e:
            print(f"Error loading existing data: {e}")
    
    print("Enter examples (Ctrl+C to finish):")
    try:
        example_num = len(examples) + 1
        while True:
            print(f"\nExample #{example_num}")
            question = input("Question: ").strip()
            if not question:
                print("Question cannot be empty. Skipping this example.")
                continue
                
            answer = input("Answer: ").strip()
            if not answer:
                print("Answer cannot be empty. Skipping this example.")
                continue
                
            context = input("Context (optional): ").strip()
            
            examples.append({
                "question": question,
                "answer": answer,
                "context": context,
                "timestamp": datetime.now().isoformat()
            })
            
            example_num += 1
            print(f"Example added. Total: {len(examples)}")
            
            if input("\nAdd another example? (y/n): ").lower() != 'y':
                break
    except KeyboardInterrupt:
        print("\nInput terminated.")
    
    # Save all examples
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(examples, f, ensure_ascii=False, indent=2)
    
    print(f"\nSaved {len(examples)} examples to {output_file}")
    return True


def main():
    parser = argparse.ArgumentParser(description="Create training datasets for the AI chatbot")
    
    # Define subparsers for different commands
    subparsers = parser.add_subparsers(dest="command", help="Command to perform")
    
    # CSV conversion command
    csv_parser = subparsers.add_parser("from-csv", help="Convert CSV to JSON dataset")
    csv_parser.add_argument("csv_file", help="Input CSV file with question-answer pairs")
    csv_parser.add_argument("--output", "-o", default="custom_dataset.json", help="Output JSON file")
    
    # Merge command
    merge_parser = subparsers.add_parser("merge", help="Merge multiple JSON datasets")
    merge_parser.add_argument("files", nargs="+", help="JSON files to merge")
    merge_parser.add_argument("--output", "-o", default="merged_dataset.json", help="Output merged file")
    
    # Interactive input command
    interactive_parser = subparsers.add_parser("interactive", help="Add examples interactively")
    interactive_parser.add_argument("--output", "-o", default="custom_dataset.json", help="Output JSON file")
    
    # Parse arguments
    args = parser.parse_args()
    
    if args.command == "from-csv":
        convert_csv_to_json(args.csv_file, args.output)
    elif args.command == "merge":
        merge_datasets(args.files, args.output)
    elif args.command == "interactive":
        add_examples_interactively(args.output)
    else:
        parser.print_help()


if __name__ == "__main__":
    sys.exit(main()) 