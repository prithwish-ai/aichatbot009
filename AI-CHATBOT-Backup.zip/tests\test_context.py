import sys
import os

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core.context_manager import ContextManager
import time

def main():
    print("Initializing ContextManager...")
    context_manager = ContextManager()
    
    print("Testing entity extraction...")
    text = "Albert Einstein was a theoretical physicist born in Germany who developed the theory of relativity."
    entities = context_manager.extract_entities(text)
    print("Extracted entities:", entities)
    
    print("\nTesting intent detection...")
    questions = [
        "What is the theory of relativity?",
        "Show me information about Albert Einstein",
        "Could you explain how electricity works?",
        "Thank you for your help"
    ]
    
    for question in questions:
        intent = context_manager.detect_intent(question)
        print(f"Question: '{question}' -> Intent: {intent}")
    
    print("\nTesting context addition and retrieval...")
    context_manager.add_context("Albert Einstein developed the theory of relativity in 1915.")
    context_manager.add_context("The theory of relativity revolutionized our understanding of physics.")
    context_manager.add_context("Einstein won the Nobel Prize in Physics in 1921.")
    context_manager.add_context("Quantum mechanics is another important theory in physics.")
    
    query = "Tell me about Einstein's theories"
    relevant_contexts = context_manager.get_relevant_context(query)
    
    print(f"Query: '{query}'")
    print("Relevant contexts:")
    for i, ctx in enumerate(relevant_contexts, 1):
        print(f"{i}. {ctx}")
    
    print("\nTesting context summarization...")
    summary = context_manager.summarize_context(max_length=200)
    print(f"Summary: {summary}")
    
    print("\nTesting entity relationships...")
    related = context_manager.get_related_entities("PERSON", "Albert Einstein")
    print(f"Entities related to Albert Einstein: {related}")
    
    print("\nTest completed successfully!")

if __name__ == "__main__":
    main() 