# AI Chatbot with Google's Gemini API

A comprehensive AI chatbot application built with Google's Gemini API, featuring contextual understanding, voice interaction, and educational capabilities.

## Project Structure

```
AI-CHATBOT/
│
├── core/                     # Core functionality
│   ├── context_manager.py    # Enhanced context and entity management
│   └── voice_manager.py      # Advanced voice interaction features
│
├── demo/                     # Simplified demo applications
│   └── simple_gemini_app.py  # Basic Gemini API demo
│
├── tests/                    # Test scripts
│   ├── test_context.py       # Tests for context manager
│   └── test_voice.py         # Tests for voice manager
│
├── utils/                    # Utility scripts
│   ├── list_gemini_models.py # List available Gemini models
│   └── call_gemini_api.py    # Direct interface to Gemini API
│
├── iti_app.py                # Main full-featured application
├── main.py                   # Application entry point
├── run.py                    # Launcher script
├── README.md                 # Documentation
└── .env                      # API keys (not tracked in Git)
```

## Features

- **Simple Gemini Demo**
  - Basic chat interface in the terminal
  - Integration with Google's Gemini 2.0 Flash model
  - Conversation history tracking
  - Colored output for better readability

- **Full Application**
  - Enhanced context management with NLP and entity recognition
  - Voice interaction with configurable voices and languages
  - GUI interface (Qt-based)
  - Progress tracking for educational topics
  - Educational content generation
  - YouTube video recommendations

## Setup

1. **Install the required packages:**

```bash
pip install -r requirements.txt
```

2. **Create a `.env` file in the project directory with your API key:**

```
GOOGLE_API_KEY=your_api_key_here
YOUTUBE_API_KEY=your_youtube_api_key_here
```

3. **Get a Google API key for Gemini:**
   - Go to https://ai.google.dev/
   - Sign up or sign in
   - Create a new API key for Gemini

## Usage

Use the launcher script to run different parts of the application:

```bash
# Run the simple demo
python run.py --demo

# Run the full application with GUI
python run.py --full

# Run in GUI mode
python run.py --gui

# Run in CLI mode
python run.py --cli

# Run tests
python run.py --test

# List available models
python run.py --models

# Call Gemini API directly
python run.py --gemini
```

Or run directly:

```bash
# Simple demo
python main.py --demo

# Full app with CLI
python main.py --cli

# With continuous learning
python main.py --cli --continuous-learning
```

## Chat Commands

The full application supports special commands:

- `!help` - Show help message with available commands
- `!clear` - Clear conversation history
- `!stats` - Show learning statistics
- `!exit` - Exit the program
- `!voice` - Toggle voice interaction
- `!language <code>` - Set language preference
- `!difficulty <level>` - Set difficulty level
- `!quiz <topic> <subtopic>` - Start a quiz
- `!study <topic> <subtopic>` - Get study materials
- `!progress` - Show learning progress
- `!recommend` - Get personalized recommendations
- `!topics` - List available topics

## Advanced Features

The full application includes:

- Enhanced context understanding with spaCy
- Voice interaction with multiple voices and languages
- Educational content generation
- Entity recognition and relationship tracking
- Semantic search for relevant context
- Conversation summarization
- YouTube video recommendations with direct links

## Troubleshooting

If you encounter issues:

1. Make sure your API key is correct and working
2. Check your internet connection
3. Verify that you have the required Python packages installed
4. For GUI issues, ensure PyQt6 is properly installed
5. For voice issues, check that your system has the required audio drivers 