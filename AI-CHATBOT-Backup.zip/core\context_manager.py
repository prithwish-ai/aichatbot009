import spacy
from typing import List, Dict, Optional, Any
import json
import os
from datetime import datetime
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

class ContextManager:
    """Enhanced context management with advanced entity recognition and memory."""
    
    def __init__(self, model_name: str = "en_core_web_sm"):
        """Initialize the context manager.
        
        Args:
            model_name: Name of the spaCy model to use
        """
        try:
            self.nlp = spacy.load(model_name)
            print(f"Successfully loaded spaCy model: {model_name}")
        except OSError:
            print(f"Installing spaCy model: {model_name}")
            os.system(f"python -m spacy download {model_name}")
            self.nlp = spacy.load(model_name)
            
        self.context_store = []
        self.entity_store = {}
        self.intent_patterns = {
            "question": ["what", "how", "why", "when", "where", "who", "which", "explain", "describe"],
            "command": ["show", "display", "generate", "create", "make", "do", "perform"],
            "clarification": ["clarify", "explain", "elaborate", "more details", "what do you mean"],
            "feedback": ["good", "bad", "great", "terrible", "helpful", "unhelpful", "thanks", "thank you"]
        }
        
        # Load existing context and entities
        self._load_context()
        self._load_entities()
    
    def _load_context(self):
        """Load context from file."""
        try:
            if os.path.exists("context_store.json"):
                with open("context_store.json", "r", encoding="utf-8") as f:
                    self.context_store = json.load(f)
                print(f"Loaded {len(self.context_store)} context entries")
        except Exception as e:
            print(f"Could not load context: {e}")
            self.context_store = []
    
    def _save_context(self):
        """Save context to file."""
        try:
            with open("context_store.json", "w", encoding="utf-8") as f:
                json.dump(self.context_store, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"Could not save context: {e}")
    
    def _load_entities(self):
        """Load entity store from file."""
        try:
            if os.path.exists("entity_store.json"):
                with open("entity_store.json", "r", encoding="utf-8") as f:
                    self.entity_store = json.load(f)
                print(f"Loaded {len(self.entity_store)} entity entries")
        except Exception as e:
            print(f"Could not load entities: {e}")
            self.entity_store = {}
    
    def _save_entities(self):
        """Save entity store to file."""
        try:
            with open("entity_store.json", "w", encoding="utf-8") as f:
                json.dump(self.entity_store, f, ensure_ascii=False, indent=2)
        except Exception as e:
            print(f"Could not save entities: {e}")
    
    def extract_entities(self, text: str) -> Dict[str, List[str]]:
        """Extract named entities from text using spaCy.
        
        Args:
            text: Input text to analyze
            
        Returns:
            Dictionary mapping entity types to lists of entities
        """
        doc = self.nlp(text)
        entities = {}
        
        for ent in doc.ents:
            if ent.label_ not in entities:
                entities[ent.label_] = []
            entities[ent.label_].append(ent.text)
            
            # Store entity in entity store
            if ent.label_ not in self.entity_store:
                self.entity_store[ent.label_] = {}
            if ent.text not in self.entity_store[ent.label_]:
                self.entity_store[ent.label_][ent.text] = {
                    "count": 0,
                    "last_seen": None,
                    "contexts": []
                }
            
            self.entity_store[ent.label_][ent.text]["count"] += 1
            self.entity_store[ent.label_][ent.text]["last_seen"] = datetime.now().isoformat()
            self.entity_store[ent.label_][ent.text]["contexts"].append(text)
            
            # Keep only last 5 contexts
            self.entity_store[ent.label_][ent.text]["contexts"] = self.entity_store[ent.label_][ent.text]["contexts"][-5:]
        
        self._save_entities()
        return entities
    
    def detect_intent(self, text: str) -> str:
        """Detect the intent of the user's input.
        
        Args:
            text: Input text to analyze
            
        Returns:
            Detected intent
        """
        text_lower = text.lower()
        
        for intent, patterns in self.intent_patterns.items():
            if any(pattern in text_lower for pattern in patterns):
                return intent
        
        return "unknown"
    
    def add_context(self, text: str, metadata: Optional[Dict[str, Any]] = None) -> None:
        """Add new context to the store.
        
        Args:
            text: Text to add
            metadata: Additional information about the context
        """
        # Extract entities from the text
        entities = self.extract_entities(text)
        
        # Create context entry
        context_entry = {
            "text": text,
            "entities": entities,
            "timestamp": datetime.now().isoformat(),
            "metadata": metadata or {}
        }
        
        # Add to context store
        self.context_store.append(context_entry)
        
        # Keep only last 1000 entries
        if len(self.context_store) > 1000:
            self.context_store = self.context_store[-1000:]
        
        self._save_context()
    
    def get_relevant_context(self, query: str, max_results: int = 5) -> List[str]:
        """Get relevant context for a query.
        
        Args:
            query: The query to find context for
            max_results: Maximum number of results to return
            
        Returns:
            List of relevant context strings
        """
        if not self.context_store:
            return []
        
        # Create TF-IDF vectors
        vectorizer = TfidfVectorizer()
        texts = [entry["text"] for entry in self.context_store]
        try:
            tfidf_matrix = vectorizer.fit_transform([query] + texts)
        except ValueError:
            return []
        
        # Calculate similarities
        similarities = cosine_similarity(tfidf_matrix[0:1], tfidf_matrix[1:])
        
        # Get top results
        top_indices = similarities[0].argsort()[-max_results:][::-1]
        
        # Return relevant contexts
        return [self.context_store[i]["text"] for i in top_indices if similarities[0][i] > 0.1]
    
    def summarize_context(self, max_length: int = 1000) -> str:
        """Summarize the current context to fit within a maximum length.
        
        Args:
            max_length: Maximum length of the summary
            
        Returns:
            Summarized context
        """
        if not self.context_store:
            return ""
        
        # Get recent contexts
        recent_contexts = self.context_store[-10:]  # Last 10 contexts
        
        # Combine texts
        combined_text = " ".join(entry["text"] for entry in recent_contexts)
        
        # If within length limit, return as is
        if len(combined_text) <= max_length:
            return combined_text
        
        # Otherwise, summarize
        doc = self.nlp(combined_text)
        sentences = [sent.text for sent in doc.sents]
        
        # Use TF-IDF to identify important sentences
        vectorizer = TfidfVectorizer()
        try:
            tfidf_matrix = vectorizer.fit_transform(sentences)
        except ValueError:
            return combined_text[:max_length]
        
        # Calculate sentence importance
        sentence_scores = np.sum(tfidf_matrix.toarray(), axis=1)
        
        # Select top sentences until we reach max_length
        summary = []
        current_length = 0
        
        for score, sentence in sorted(zip(sentence_scores, sentences), reverse=True):
            if current_length + len(sentence) <= max_length:
                summary.append(sentence)
                current_length += len(sentence)
            else:
                break
        
        return " ".join(summary)
    
    def get_entity_history(self, entity_type: str, entity_text: str) -> Dict[str, Any]:
        """Get the history of a specific entity.
        
        Args:
            entity_type: Type of the entity
            entity_text: Text of the entity
            
        Returns:
            Dictionary containing entity history
        """
        return self.entity_store.get(entity_type, {}).get(entity_text, {})
    
    def get_related_entities(self, entity_type: str, entity_text: str) -> List[str]:
        """Get related entities based on context.
        
        Args:
            entity_type: Type of the entity
            entity_text: Text of the entity
            
        Returns:
            List of related entity texts
        """
        if entity_type not in self.entity_store or entity_text not in self.entity_store[entity_type]:
            return []
        
        # Get contexts where this entity appears
        contexts = self.entity_store[entity_type][entity_text]["contexts"]
        
        # Find other entities in these contexts
        related_entities = set()
        for context in contexts:
            doc = self.nlp(context)
            for ent in doc.ents:
                if ent.text != entity_text:
                    related_entities.add(ent.text)
        
        return list(related_entities) 