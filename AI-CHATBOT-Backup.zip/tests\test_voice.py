import sys
import os

# Add parent directory to path for imports
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core.voice_manager import VoiceManager
import time

def main():
    print("Initializing VoiceManager...")
    voice_manager = VoiceManager()
    
    print("Available voices:")
    voices = voice_manager.get_available_voices()
    for i, voice in enumerate(voices[:5]):  # Show up to 5 voices
        print(f"{i+1}. {voice['name']} ({voice['gender']})")
    
    print("\nCurrent voice settings:")
    settings = voice_manager.get_voice_settings()
    for key, value in settings.items():
        print(f"{key}: {value}")
    
    print("\nTesting speech generation...")
    test_text = "Hello! This is a test of the voice manager. It can convert text to speech."
    print(f"Speaking: '{test_text}'")
    voice_manager.speak(test_text)
    
    print("\nChanging voice settings...")
    voice_manager.set_rate(150)  # Normal speed
    voice_manager.set_volume(0.8)  # 80% volume
    
    print("\nTesting speech with new settings...")
    test_text2 = "This is a test with adjusted speed and volume settings."
    print(f"Speaking: '{test_text2}'")
    voice_manager.speak(test_text2)
    
    if len(voices) > 1:
        print("\nTesting different voice...")
        voice_manager.set_voice(voices[1]['id'])
        test_text3 = "This is a test with a different voice."
        print(f"Speaking: '{test_text3}'")
        voice_manager.speak(test_text3)
    
    print("\nTest completed successfully!")

if __name__ == "__main__":
    main() 