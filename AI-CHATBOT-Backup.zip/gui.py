from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                           QHBoxLayout, QTextEdit, QPushButton, QLabel, 
                           QComboBox, QProgressBar, QTabWidget, QScrollArea)
from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtGui import QFont, QPalette, QColor
import sys
import os

# Add core directory to path for imports
sys.path.append(os.path.join(os.path.dirname(__file__), 'core'))

# Import from core modules
from core.context_manager import ContextManager
from iti_app import ChatBot

class ChatThread(QThread):
    """Thread for handling chat operations."""
    response_ready = pyqtSignal(str)
    progress_updated = pyqtSignal(dict)
    
    def __init__(self, chatbot, query):
        super().__init__()
        self.chatbot = chatbot
        self.query = query
        
    def run(self):
        response = self.chatbot._process_query(self.query)
        self.response_ready.emit(response)
        
        # Update progress
        progress = self.chatbot.progress_tracker.progress_data
        self.progress_updated.emit(progress)

class MainWindow(QMainWindow):
    """Main window of the chatbot application."""
    
    def __init__(self):
        super().__init__()
        self.setWindowTitle("ITI AI Chatbot")
        self.setMinimumSize(800, 600)
        
        # Initialize chatbot and context manager
        self.chatbot = ChatBot(continuous_learning=True)
        self.context_manager = ContextManager()
        
        # Create main widget and layout
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        layout = QVBoxLayout(main_widget)
        
        # Create tab widget
        tabs = QTabWidget()
        layout.addWidget(tabs)
        
        # Chat tab
        chat_tab = QWidget()
        chat_layout = QVBoxLayout(chat_tab)
        
        # Chat history
        self.chat_history = QTextEdit()
        self.chat_history.setReadOnly(True)
        chat_layout.addWidget(self.chat_history)
        
        # Input area
        input_layout = QHBoxLayout()
        self.input_field = QTextEdit()
        self.input_field.setMaximumHeight(100)
        input_layout.addWidget(self.input_field)
        
        send_button = QPushButton("Send")
        send_button.clicked.connect(self.send_message)
        input_layout.addWidget(send_button)
        
        chat_layout.addLayout(input_layout)
        
        # Progress tab
        progress_tab = QWidget()
        progress_layout = QVBoxLayout(progress_tab)
        
        # Progress scroll area
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll_content = QWidget()
        scroll_layout = QVBoxLayout(scroll_content)
        
        # Progress bars for each topic
        self.progress_bars = {}
        for category, topics in self.chatbot.progress_tracker.ITI_TOPICS.items():
            category_label = QLabel(category)
            category_label.setFont(QFont("Arial", 12, QFont.Weight.Bold))
            scroll_layout.addWidget(category_label)
            
            for topic in topics:
                topic_layout = QHBoxLayout()
                
                topic_label = QLabel(topic)
                topic_label.setMinimumWidth(200)
                topic_layout.addWidget(topic_label)
                
                progress_bar = QProgressBar()
                progress_bar.setMinimum(0)
                progress_bar.setMaximum(100)
                progress_bar.setValue(0)
                topic_layout.addWidget(progress_bar)
                
                scroll_layout.addLayout(topic_layout)
                self.progress_bars[topic] = progress_bar
        
        scroll.setWidget(scroll_content)
        progress_layout.addWidget(scroll)
        
        # Add tabs
        tabs.addTab(chat_tab, "Chat")
        tabs.addTab(progress_tab, "Progress")
        
        # Set dark theme
        self.set_dark_theme()
        
        # Connect signals
        self.input_field.returnPressed.connect(self.send_message)
        
    def set_dark_theme(self):
        """Set dark theme for the application."""
        palette = QPalette()
        palette.setColor(QPalette.ColorRole.Window, QColor(53, 53, 53))
        palette.setColor(QPalette.ColorRole.WindowText, Qt.GlobalColor.white)
        palette.setColor(QPalette.ColorRole.Base, QColor(25, 25, 25))
        palette.setColor(QPalette.ColorRole.AlternateBase, QColor(53, 53, 53))
        palette.setColor(QPalette.ColorRole.ToolTipBase, Qt.GlobalColor.white)
        palette.setColor(QPalette.ColorRole.ToolTipText, Qt.GlobalColor.white)
        palette.setColor(QPalette.ColorRole.Text, Qt.GlobalColor.white)
        palette.setColor(QPalette.ColorRole.Button, QColor(53, 53, 53))
        palette.setColor(QPalette.ColorRole.ButtonText, Qt.GlobalColor.white)
        palette.setColor(QPalette.ColorRole.BrightText, Qt.GlobalColor.red)
        palette.setColor(QPalette.ColorRole.Link, QColor(42, 130, 218))
        palette.setColor(QPalette.ColorRole.Highlight, QColor(42, 130, 218))
        palette.setColor(QPalette.ColorRole.HighlightedText, Qt.GlobalColor.black)
        
        QApplication.setPalette(palette)
        
    def send_message(self):
        """Send a message and get response from the chatbot."""
        query = self.input_field.toPlainText().strip()
        if not query:
            return
            
        # Clear input field
        self.input_field.clear()
        
        # Add user message to chat history
        self.chat_history.append(f"<p style='color: #42daf4;'>You: {query}</p>")
        
        # Create and start chat thread
        self.chat_thread = ChatThread(self.chatbot, query)
        self.chat_thread.response_ready.connect(self.handle_response)
        self.chat_thread.progress_updated.connect(self.update_progress)
        self.chat_thread.start()
        
    def handle_response(self, response):
        """Handle the chatbot's response."""
        self.chat_history.append(f"<p style='color: #42ff42;'>Bot: {response}</p>")
        self.chat_history.verticalScrollBar().setValue(
            self.chat_history.verticalScrollBar().maximum()
        )
        
    def update_progress(self, progress_data):
        """Update progress bars with new progress data."""
        for category, topics in progress_data.items():
            for topic, data in topics.items():
                if topic in self.progress_bars:
                    self.progress_bars[topic].setValue(data.get("progress", 0))

def main():
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main() 